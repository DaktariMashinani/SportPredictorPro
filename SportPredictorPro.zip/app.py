from flask import Flask, request, jsonify, send_from_directory
import os

app = Flask(__name__, static_folder='static')

teams_data = {
    "soccer": {
        "Team A": 85,
        "Team B": 75,
        "Team C": 90
    },
    "basketball": {
        "Team X": 95,
        "Team Y": 88,
        "Team Z": 82
    },
    "football": {
        "Team R": 89,
        "Team S": 91,
        "Team T": 84
    }
}

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route("/teams/<sport>")
def get_teams(sport):
    return jsonify(list(teams_data.get(sport, {}).keys()))

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    sport = data.get("sport")
    team1 = data.get("team1")
    team2 = data.get("team2")

    if sport not in teams_data or team1 not in teams_data[sport] or team2 not in teams_data[sport]:
        return jsonify({"error": "Invalid input"}), 400

    strength1 = teams_data[sport][team1]
    strength2 = teams_data[sport][team2]

    total = strength1 + strength2
    prob1 = strength1 / total

    winner = team1 if prob1 >= 0.5 else team2

    return jsonify({
        "sport": sport,
        "team1": team1,
        "team2": team2,
        "predicted_winner": winner
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=81)
